//----------------------------------------------
//Chatting v1.0 Source By Bermann
//dobermann75@gmail.com
//----------------------------------------------

function Chatting()
{
	this.time = 0;
	this.cycle = 1000;
	this.canvas = null;
	this.status = null;
	this.username = null;
	this.message = null;
	this.handlingPage = null;
	this.setTimeOut = null;
}

Chatting.prototype =
{
	sendData: function (code) {
		if (code == 13) {
			var This = this;
			var username = encodeURIComponent(this.username.value);
			var message = encodeURIComponent(this.message.value);
			if (!username) { alert("이름입력"); this.username.focus(); return; }
			if (!message) { alert("메세지입력"); this.message.focus(); return; }
			var request = new Ajax("POST",this.handlingPage,true,"XML","username=" + username + "&message=" + message,function () {
				This.getData(request.Result);
				request = null;
			});
			this.message.value = "";
		}
	},
	getData: function (request) {
		var results = request.getElementsByTagName("chatting")[0];
		for (var i = 0; i < results.childNodes.length; i++) {
			if (results.childNodes[i].getElementsByTagName("username")[0]) {
				var element = document.createElement("DIV");
				var username = results.childNodes[i].getElementsByTagName("username")[0].firstChild.nodeValue;
				var message = results.childNodes[i].getElementsByTagName("message")[0].firstChild.nodeValue;
				var time = results.childNodes[i].getElementsByTagName("time")[0].firstChild.nodeValue;
				if ($(time)) { continue; }
				element.id = time;
				element.innerHTML = username + " : " + message;
				this.canvas.appendChild(element);
				element.scrollIntoView(true);
			}
			if (i == results.childNodes.length - 1) {
				this.time = results.childNodes[i].getElementsByTagName("time")[0].firstChild.nodeValue;
				var status = results.childNodes[i].getElementsByTagName("status")[0];
				var statusLength = status.getElementsByTagName("user").length;
				var statusList = "";
				for (var j = 0; j < statusLength; j++) {
					var user = status.getElementsByTagName("user")[j].firstChild.nodeValue;
					var ip = status.getElementsByTagName("ip")[j].firstChild.nodeValue;
					statusList += "<div><nobr>" + user + " <small>[" + ip + "]</small></nobr></div>";
				}
				this.status.innerHTML = statusList;
			}
		}
		results = null;
		request = null;
	},
	Run: function () {
		if (this.canvas == null || this.username == null || this.message == null || this.handlingPage == null) { return; }
		if (Number(this.cycle) < 500) { this.cycle = 500; }
		var This = this;
		var currentStart = new Date().getTime();
		var request = new Ajax("POST",this.handlingPage,true,"XML","time=" + this.time,function () {
			var currentEnd = new Date().getTime();
			if (Number(currentEnd) - Number(currentStart) > This.cycle) { request = null; return; }
			This.getData(request.Result);
			request = null;
		});
		if (this.setTimeOut != null) { window.clearTimeout(this.setTimeOut); }
		this.setTimeOut = window.setTimeout(function () { This.Run(); },this.cycle);
	}
}
